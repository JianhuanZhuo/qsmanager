package cn.keepfight.qsmanager;

/**
 * Created by tom on 2017/6/6.
 */
public enum StateList {

}
