package cn.keepfight.qsmanager;

import javafx.application.Application;

/**
 * loader of client application.
 * Created by tom on 2017/5/30.
 */
public class AppLoader {

    public static void main(String[] args) {
        Application.launch(cn.keepfight.qsmanager.QSApp.class, args);
    }
}
