package cn.keepfight.qsmanager.controller;

import java.util.List;

/**
 * Created by tom on 2017/6/17.
 */
public interface OutComeSub {

    void setYearSelection(List<Long> ls);
}
