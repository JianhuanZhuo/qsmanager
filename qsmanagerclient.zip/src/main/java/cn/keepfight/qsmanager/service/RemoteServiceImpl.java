package cn.keepfight.qsmanager.service;

/**
 * 远程服务接口
 * Created by tom on 2017/6/6.
 */
public class RemoteServiceImpl {


}
