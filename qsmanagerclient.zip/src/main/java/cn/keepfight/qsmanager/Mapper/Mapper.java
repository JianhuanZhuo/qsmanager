package cn.keepfight.qsmanager.Mapper;

/**
 * 映射器
 * Created by tom on 2017/6/7.
 */
public interface Mapper {
}
