package cn.keepfight.qsmanager.model;

/**
 * 汇总统计模型
 * Created by tom on 2017/6/17.
 */
public class TPStatModel {
    private String mon;
    private String rec;
    private String pay;

    public String getMon() {
        return mon;
    }

    public void setMon(String mon) {
        this.mon = mon;
    }

    public String getRec() {
        return rec;
    }

    public void setRec(String rec) {
        this.rec = rec;
    }

    public String getPay() {
        return pay;
    }

    public void setPay(String pay) {
        this.pay = pay;
    }
}
